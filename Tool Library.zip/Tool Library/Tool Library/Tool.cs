﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tool_Library
{
    class Tool
    {
        public int len = 0;//Total number of tools 
        public int custLen = 0;//total number of customer
        //Tool type details
        public int[] toolAvailability = new int[50];//Store the availability of a particulat tool. Max Length is 50.
        public string[] toolName = new string[50];//Store the name of the tool. Maximum it can store 50 different type of tools.
        public string[] toolDescription = new string[50];//Store the Description of tool. Maximum it can store 50 different type of tool Description.
        //Customer detail
        public string[] custName = new string[50];//Store the Customer name who lend the tool. Maximum it can store 50 different type of Customer name.
        public long[] custNumber = new long[50];//Store the Customer mobile number who lend the tool. Maximum it can store 50 different type of  Customer name.
        public string[] custTool = new string[50];//Store the type of tool customer lend. Maximum it can store 50 different type of  Customer name.
        public int[] custQty = new int[50];//Store the quantity of the tool that customer lend. Maximum it can store 50 different type of  Customer name.

        public void sort()//Function to sort the cstomer details alphabetically
        {
            int i,j;
            for (i=0;i<len;i++)
            {
                for(j=0;j<len-1;j++)
                {
                    if(toolName[j].CompareTo(toolName[j+1])>0)
                    {
                        string temp1 = toolName[j];
                        toolName[j]=toolName[j+1];
                        toolName[j+1]=temp1;

                        string temp2;
                        temp2=toolDescription[j];
                        toolDescription[j] = toolDescription[j + 1];
                        toolDescription[j + 1] = temp2;

                        int temp3 = toolAvailability[j];
                        toolAvailability[j] = toolAvailability[j + 1];
                        toolAvailability[j + 1] = temp3;
                    }
                }
            }
        }
        public void change()//function to change the number of tool
        {
            len += 1;
        }
        public void insertToolName(string name)//function to insert the tool name 
        {
            toolName[len] = name;
        }
        public void insertToolDescription(string name)//function to insert the tool Description 
        {
            toolDescription[len] = name;
        }
        public void insertToolAvailability(int n)//function to insert the tool Quantity 
        {
            toolAvailability[len] = n;
        }
        public bool present(string name, int quant)//function to check whether tool is present in the system or not
        {
            int i;
            for (i = 0; i < len; i++)
            {
                if (toolName[i] == name)
                {
                    toolAvailability[i] += quant;
                    Console.WriteLine("Tool Already existed, Quantity updated");
                    return true;
                }
            }
            return false;
        }
        public bool check(string name, int n)//function to check whether required number of tools present in the system or not
        {
            int i;
            for (i = 0; i < len; i++)
            {
                if (toolName[i] == name)
                {
                    if (toolAvailability[i] >= n)
                    {
                        toolAvailability[i] -= n;
                        return true;
                    }
                }
            }
            return false;
        }
        public void insert(string n, long num, int qty, string name)//function to insert the Customer detail and which tool he/she lend.
        {
            custName[custLen] = n;
            custNumber[custLen] = num;
            custQty[custLen] = qty;
            custTool[custLen] = name;
            custLen += 1;
        }
        public void display()//function to display the data
            sort();
            int i;

            if (len == 0)
                Console.WriteLine("Nothing Too Display");
            else
            {

                Console.WriteLine("_____________________________________________________________________________");
                for (i = 0; i < len; i++)
                {
                    Console.WriteLine("Tool Name : {0}", toolName[i]);

                    Console.WriteLine("Tool Desciption : {0}", toolDescription[i]);

                    Console.WriteLine("Tool Quantity : {0}", toolAvailability[i]);

                    Console.WriteLine("_____________________________________________________________________________");
                }
            }
        }
        public bool rented(string cName, string tName)//function to return a rented tool
        {
            int i, j;
            for (i = 0; i < custLen; i++)
            {
                if (custTool[i] == tName)
                {
                    if (custName[i] == cName)
                    {
                        toolAvailability[i] += custQty[i];
                        for (j=i;j<custLen-1;j++)
                        {
                            custName[j] = custName[j + 1];
                            custNumber[j] = custNumber[j + 1];
                            custQty[j] = custQty[j + 1];
                            custTool[j] = custTool[j + 1];
                        }
                        custLen -= 1;
                        return true;
                    }

                }
            }
            return false;
        }

    }
}
