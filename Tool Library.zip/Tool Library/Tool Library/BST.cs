﻿using System;

namespace Tool_Library
{
    class BST
    {
        public class Node
        {
            public int Data;
            public Node Left;
            public Node Right;

        }
        public Node root;
        public BST()
        {
            root = null;
            Insert(1);//1 Represent Automotive Tools
            Insert(2);//2 Represent Cleaning Tools
            Insert(3);//3 Represent Electricity Tools
            Insert(4);//4 Represent Electronic Tools
            Insert(5);//5 Represent Fencing Tools
            Insert(6);//6 Represent Flooring Tools
            Insert(7);//7 Represent Gardening Tools
            Insert(8);//8 Represent Measuring Tools
            Insert(9);//9 Represent Painting Tools

        }

        public bool SearchElement_Rec(int element, Node root)
        {

            Node current = root;

            if (current == null)

                return false;

            if (element == current.Data)

                return true;

            if (element < current.Data)

                return this.SearchElement_Rec(element, current.Left);

            else

                return this.SearchElement_Rec(element, current.Right);

        }

        public void Insert(int i)
        {
            Node newNode = new Node();
            newNode.Data = i;
            if (root == null)
                root = newNode;
            else
            {
                Node current = root;
                Node parent;
                while (true)
                {
                    parent = current;
                    if (i < current.Data)
                    {
                        current = current.Left;
                        if (current == null)
                        {
                            parent.Left = newNode;
                            break;
                        }
                    }

                    else
                    {
                        current = current.Right;
                        if (current == null)
                        {
                            parent.Right = newNode;
                            break;
                        }

                    }
                }
            }
        }
    }
}



