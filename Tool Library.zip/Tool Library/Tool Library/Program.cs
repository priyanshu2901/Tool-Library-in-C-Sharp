﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Tool_Library
{

    class Program
    {
        public static inventory_management_system ims = new inventory_management_system();//Creating object of Inventor management system.
        static void Main(string[] args)
        {
            while (true)
            {

                Console.WriteLine("\n1.Display the information about a the tools");
                Console.WriteLine("2.Add new tool");
                Console.WriteLine("3.Lend a tool");
                Console.WriteLine("4.Return a rented tool");
                Console.WriteLine("5.Exit");
                Console.Write("\nEnter Your Choice : ");

                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        ims.display();
                        break;
                    case 2:

                        ims.Add();
                        break;
                    case 3:

                        ims.lend();
                        break;
                    case 4:
                        ims.returnRented();
                        break;
                    case 5:
                        System.Environment.Exit(1);
                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }
            }
        }
    }
}
