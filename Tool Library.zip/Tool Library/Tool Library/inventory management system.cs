﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tool_Library
{
    class inventory_management_system
    {

        public static Tool Automotive = new Tool();//object for Automotive tool
        public static Tool Cleaning = new Tool();//object for Cleaning tool
        public static Tool Electricity = new Tool();//object for Electricity tool
        public static Tool Electronic = new Tool();//object for Electronic tool
        public static Tool Fencing = new Tool();//object for Fencing tool
        public static Tool Flooring = new Tool();//object for Flooring tool
        public static Tool Gardening = new Tool();//object for Gardening tool
        public static Tool Measuring = new Tool();//object for Measuring tool
        public static Tool Painting = new Tool();//object for Painting tool
        public static BST bstObj = new BST();//object for Binary search tree which store the tool type.
        public static int menu()
        {
            int type;

            while (true)
            {

                Console.WriteLine("\nSelect tool type : ");
                Console.WriteLine("1.Automotive tools ");
                Console.WriteLine("2.Cleaning tools");
                Console.WriteLine("3.Electricity tools");
                Console.WriteLine("4.Electronic tools ");
                Console.WriteLine("5.Fencing tools ");
                Console.WriteLine("6.Flooring tools");
                Console.WriteLine("7.Gardening tools");
                Console.WriteLine("8.Measuring tools");
                Console.WriteLine("9.Painting tools");
                Console.Write("\nEnter Your choice : ");
                type = Convert.ToInt32(Console.ReadLine());
                if (bstObj.SearchElement_Rec(type,bstObj.root)==true)//check whether tool is present in bst or not
                    return type;
                else
                    Console.WriteLine("Wrong Choice");
            }


        }
        public void Add()//function to add tool in the system
        {
            try
            {
                int type = menu();
                Console.Write("Enter Tool Name : ");
                string name = Console.ReadLine();
                Console.Write("Enter description : ");
                string dris = Console.ReadLine();
                Console.Write("Enter Quantity : ");
                int avail = Convert.ToInt32(Console.ReadLine());
                switch (type)
                {
                    case 1:
                    //for Automotive tool
                        if (Automotive.present(name, avail) == false)
                        {

                            Automotive.insertToolAvailability(avail);
                            Automotive.insertToolDescription(dris);
                            Automotive.insertToolName(name);
                            Automotive.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 2:
                    //for Cleaning tool
                        if (Cleaning.present(name, avail) == false)
                        {
                            Cleaning.insertToolAvailability(avail);
                            Cleaning.insertToolDescription(dris);
                            Cleaning.insertToolName(name);
                            Cleaning.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 3:
                    //for Electricity tool
                        if (Electricity.present(name, avail) == false)
                        {
                            Electricity.insertToolAvailability(avail);
                            Electricity.insertToolDescription(dris);
                            Electricity.insertToolName(name);
                            Electricity.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 4:
                    //for Electronic tool
                        if (Electronic.present(name, avail) == false)
                        {
                            Electronic.insertToolAvailability(avail);
                            Electronic.insertToolDescription(dris);
                            Electronic.insertToolName(name);
                            Electronic.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 5:
                    //for Fencing tool
                        if (Fencing.present(name, avail) == false)
                        {
                            Fencing.insertToolAvailability(avail);
                            Fencing.insertToolDescription(dris);
                            Fencing.insertToolName(name);
                            Fencing.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 6:
                    //for Flooring tool
                        if (Flooring.present(name, avail) == false)
                        {
                            Flooring.insertToolAvailability(avail);
                            Flooring.insertToolDescription(dris);
                            Flooring.insertToolName(name);
                            Flooring.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 7:
                    //for Gardening tool
                        if (Gardening.present(name, avail) == false)
                        {
                            Gardening.insertToolAvailability(avail);
                            Gardening.insertToolDescription(dris);
                            Gardening.insertToolName(name);
                            Gardening.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 8:
                    //for Measuring tool
                        if (Measuring.present(name, avail) == false)
                        {
                            Measuring.insertToolAvailability(avail);
                            Measuring.insertToolDescription(dris);
                            Measuring.insertToolName(name);
                            Measuring.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    case 9:
                    //for Painting tool
                        if (Painting.present(name, avail) == false)
                        {
                            Painting.insertToolAvailability(avail);
                            Painting.insertToolDescription(dris);
                            Painting.insertToolName(name);
                            Painting.change();
                            Console.WriteLine("Tool Added ");
                        }
                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }

            }
            catch (FormatException)
            {
                Console.WriteLine("Exception Occured");
            }
        }
        public void lend()//function to lend a tool
        {
            try
            {
                int type = menu();

                Console.Write("Enter Tool Name : ");
                string name = Console.ReadLine();
                Console.Write("Enter Quantity : ");
                int avail = Convert.ToInt32(Console.ReadLine());
                switch (type)
                {
                    case 1:
                        if (Automotive.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Automotive.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 2:
                        if (Cleaning.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Cleaning.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 3:
                        if (Electricity.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Electricity.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 4:
                        if (Electronic.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Electronic.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 5:
                        if (Fencing.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Fencing.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 6:
                        if (Flooring.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Flooring.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 7:
                        if (Gardening.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Gardening.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 8:
                        if (Measuring.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Measuring.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    case 9:
                        if (Painting.check(name, avail) == true)
                        {
                            Console.Write("Enter Customer Name :");
                            string n = Console.ReadLine();
                            Console.Write("Enter Customer Number :");
                            long num = long.Parse(Console.ReadLine());
                            Painting.insert(n, num, avail, name);
                            Console.WriteLine("Tool Successfully Lended");
                        }
                        else
                            Console.WriteLine("Either product name is wrong or it is not available");
                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Exception Occured");
            }

        }
        public void display()//function to display the detail of a particular tool
        {
            try
            {
                int type = menu();
                switch (type)
                {
                    case 1:
                        Automotive.display();
                        break;
                    case 2:
                        Cleaning.display();
                        break;
                    case 3:
                        Electricity.display();
                        break;
                    case 4:
                        Electronic.display();
                        break;
                    case 5:
                        Fencing.display();
                        break;
                    case 6:
                        Flooring.display();
                        break;
                    case 7:
                        Gardening.display();
                        break;
                    case 8:
                        Measuring.display();
                        break;
                    case 9:
                        Painting.display();
                        break;
                    default:
                        Console.WriteLine("Wrong Choice");
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Exception Occured");
            }
        }
        public void returnRented()//function to return a rented tool
        {
            try
            {
                int type = menu();
                Console.Write("Enter customer name : ");
                string cName = Console.ReadLine();
                Console.Write("Enter Tool Name : ");
                string tName = Console.ReadLine();

                switch (type)
                {
                    case 1:
                        if (Automotive.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 2:
                        if (Cleaning.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 3:
                        if (Electricity.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 4:
                        if (Electronic.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 5:
                        if (Fencing.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 6:
                        if (Flooring.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 7:
                        if (Gardening.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 8:
                        if (Measuring.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    case 9:
                        if (Painting.rented(cName, tName) == false)
                        {
                            Console.WriteLine("Either customer name is wrong or tool name");
                        }
                        else
                        {
                            Console.WriteLine("Tool Successfull Returned");
                        }
                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }

            }
            catch (FormatException)
            {
                Console.WriteLine("Exception Occured");
            }
        }
    }
}

